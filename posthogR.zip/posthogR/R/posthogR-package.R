#' posthogR: Query PostHog Analytics Data via HogQL from R
#'
#' An unofficial R client for the PostHog product analytics API.
#' Authenticate with [ph_auth()], then pull data with [ph_query()]
#' (raw HogQL), [ph_events()] (a convenience wrapper for recent events),
#' or [ph_insight()] (re-run a saved insight).
#'
#' @keywords internal
"_PACKAGE"
