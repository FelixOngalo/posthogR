# Internal: build and perform an authenticated POST request to PostHog's
# query endpoint. Every user-facing query function (ph_query, ph_events,
# ph_insight) is a thin wrapper around this.

#' @importFrom rlang .data
NULL

ph_post_query <- function(query_body) {
  creds <- ph_check_auth()

  req <- httr2::request(creds$host) |>
    httr2::req_url_path_append("api", "projects", creds$project_id, "query") |>
    httr2::req_headers(Authorization = paste("Bearer", creds$api_key)) |>
    httr2::req_body_json(list(query = query_body)) |>
    httr2::req_user_agent("posthogR (https://github.com/yourusername/posthogR)") |>
    httr2::req_retry(max_tries = 3, backoff = \(n) 2^n) |>
    httr2::req_error(is_error = \(resp) FALSE)  # we check status ourselves, for a clearer message

  resp <- httr2::req_perform(req)
  status <- httr2::resp_status(resp)

  if (status >= 400) {
    body_text <- tryCatch(httr2::resp_body_string(resp), error = \(e) "")
    cli::cli_abort(c(
      "PostHog API request failed with status {status}.",
      "x" = "{body_text}"
    ))
  }

  httr2::resp_body_json(resp, simplifyVector = FALSE)
}

# Internal: convert a HogQL query response (columns + row-of-lists results)
# into a tibble. PostHog returns `results` as a list of rows, each row a
# list of column values in the same order as `columns` -- this reshapes
# that into one column per field, which is what R users actually want.
ph_response_to_tibble <- function(resp) {
  cols <- unlist(resp$columns)
  rows <- resp$results

  if (length(rows) == 0) {
    out <- stats::setNames(
      lapply(cols, \(x) logical(0)),
      cols
    )
    return(tibble::as_tibble(out))
  }

  mat <- do.call(rbind, lapply(rows, \(row) {
    vapply(row, \(cell) if (is.null(cell)) NA_character_ else as.character(cell),
          character(1))
  }))
  colnames(mat) <- cols

  tibble::as_tibble(mat)
}
