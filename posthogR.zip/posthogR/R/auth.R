#' Authenticate with PostHog
#'
#' Stores your PostHog personal API key, project ID, and host for the
#' current R session, so you don't have to pass them to every call.
#' The key is kept only in memory (an environment internal to the
#' package) -- it is never written to disk by this function.
#'
#' @param api_key Character. A PostHog personal API key (looks like
#'   `phx_...`). Create one at Settings -> Personal API Keys in your
#'   PostHog project, scoped to at least `query:read`.
#' @param project_id Character or numeric. Your PostHog project ID,
#'   found in Settings -> Project -> Project ID.
#' @param host Character. Your PostHog instance's API host. Defaults to
#'   PostHog Cloud US (`"https://us.posthog.com"`). Use
#'   `"https://eu.posthog.com"` for the EU cloud, or your own URL for a
#'   self-hosted instance.
#'
#' @details
#' For scripts you intend to share or commit, don't hardcode the key.
#' Store it as an environment variable (e.g. in `.Renviron`:
#' `POSTHOG_API_KEY=phx_...`) and call
#' `ph_auth(Sys.getenv("POSTHOG_API_KEY"), project_id = "12345")`.
#'
#' @return Invisibly returns `TRUE`. Called for its side effect of
#'   storing credentials for the session.
#' @export
#'
#' @examples
#' \dontrun{
#' ph_auth(
#'   api_key    = Sys.getenv("POSTHOG_API_KEY"),
#'   project_id = "12345"
#' )
#' }
ph_auth <- function(api_key, project_id, host = "https://us.posthog.com") {
  if (missing(api_key) || !nzchar(api_key)) {
    cli::cli_abort("{.arg api_key} is required. Create one in PostHog under Settings > Personal API Keys.")
  }
  if (missing(project_id) || !nzchar(as.character(project_id))) {
    cli::cli_abort("{.arg project_id} is required. Find it in PostHog under Settings > Project.")
  }

  .posthogR_env$api_key    <- api_key
  .posthogR_env$project_id <- as.character(project_id)
  .posthogR_env$host       <- sub("/$", "", host)

  cli::cli_alert_success("PostHog credentials set for this session (project {.val {project_id}}).")
  invisible(TRUE)
}

# Internal environment holding session credentials. Not exported --
# access only through ph_auth() and the internal helper below.
.posthogR_env <- new.env(parent = emptyenv())

# Internal: fetch stored credentials, erroring with a helpful message
# if ph_auth() hasn't been called yet. Every exported function that
# talks to the API should call this first.
ph_check_auth <- function() {
  if (is.null(.posthogR_env$api_key)) {
    cli::cli_abort(c(
      "Not authenticated with PostHog.",
      "i" = "Call {.fn ph_auth} first, e.g. {.code ph_auth(api_key, project_id)}."
    ))
  }
  list(
    api_key    = .posthogR_env$api_key,
    project_id = .posthogR_env$project_id,
    host       = .posthogR_env$host
  )
}
