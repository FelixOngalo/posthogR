#' Run a raw HogQL query against PostHog
#'
#' HogQL is PostHog's SQL-like query language, run against your events,
#' persons, and (if enabled) data warehouse tables. This is the most
#' flexible way to pull PostHog data into R -- if you can write it as a
#' SELECT statement, you can get it as a tibble.
#'
#' @param sql Character. A HogQL query string, e.g.
#'   `"SELECT event, count() FROM events GROUP BY event ORDER BY count() DESC"`.
#'
#' @return A [tibble::tibble()] with one column per field returned by the
#'   query. All columns are returned as character; convert types
#'   (`readr::type_convert()` or `dplyr::mutate()`) as needed, since
#'   HogQL's response format doesn't preserve R-specific types.
#' @export
#'
#' @examples
#' \dontrun{
#' ph_auth(Sys.getenv("POSTHOG_API_KEY"), project_id = "12345")
#'
#' ph_query("SELECT event, count() FROM events GROUP BY event ORDER BY count() DESC LIMIT 10")
#' }
ph_query <- function(sql) {
  if (missing(sql) || !nzchar(sql)) {
    cli::cli_abort("{.arg sql} must be a non-empty HogQL query string.")
  }

  resp <- ph_post_query(list(kind = "HogQLQuery", query = sql))
  ph_response_to_tibble(resp)
}

#' Fetch recent events as a tibble
#'
#' A convenience wrapper around [ph_query()] for the most common
#' request: "give me the last N events, optionally filtered by event
#' name or date range."  For anything more specific, write your own
#' HogQL with [ph_query()] instead.
#'
#' @param event Character or `NULL`. Restrict to a single event name
#'   (e.g. `"$pageview"`, `"signup_completed"`). `NULL` (the default)
#'   returns all event types.
#' @param since Character or `NULL`. A date (e.g. `"2026-09-01"`) to
#'   filter events from. `NULL` (the default) applies no lower bound.
#' @param limit Integer. Maximum rows to return. Default `1000`.
#'
#' @return A [tibble::tibble()] of events with columns `event`,
#'   `timestamp`, `distinct_id`, and `properties` (as a JSON string --
#'   see Details).
#'
#' @details
#' `properties` is returned as a raw JSON string rather than parsed
#' columns, since different events have different property shapes.
#' Use `jsonlite::fromJSON()` or `tidyjson` to unpack the properties
#' you need, or write a custom [ph_query()] with `properties.your_key`
#' to pull out specific fields directly in HogQL.
#'
#' @export
#'
#' @examples
#' \dontrun{
#' ph_auth(Sys.getenv("POSTHOG_API_KEY"), project_id = "12345")
#'
#' ph_events(event = "$pageview", since = "2026-09-01", limit = 500)
#' }
ph_events <- function(event = NULL, since = NULL, limit = 1000) {
  where_clauses <- character(0)
  if (!is.null(event)) {
    where_clauses <- c(where_clauses, sprintf("event = '%s'", event))
  }
  if (!is.null(since)) {
    where_clauses <- c(where_clauses, sprintf("timestamp >= '%s'", since))
  }

  where_sql <- if (length(where_clauses) > 0) {
    paste("WHERE", paste(where_clauses, collapse = " AND "))
  } else {
    ""
  }

  sql <- sprintf(
    "SELECT event, timestamp, distinct_id, properties FROM events %s ORDER BY timestamp DESC LIMIT %d",
    where_sql, as.integer(limit)
  )

  ph_query(sql)
}

#' Fetch the results of a saved PostHog insight
#'
#' Re-runs an existing insight (a saved trend, funnel, retention chart,
#' etc. built in the PostHog UI) and returns its current results as a
#' tibble, so a report you already built visually can be refreshed from
#' R on a schedule.
#'
#' @param insight_id Character or numeric. The insight's short ID, found
#'   in its URL in the PostHog app (e.g. the `AbCdEfGh` in
#'   `.../insights/AbCdEfGh`).
#'
#' @return A [tibble::tibble()] of the insight's result rows. Column
#'   names depend on the insight type (trend, funnel, etc.).
#' @export
#'
#' @examples
#' \dontrun{
#' ph_auth(Sys.getenv("POSTHOG_API_KEY"), project_id = "12345")
#'
#' ph_insight("AbCdEfGh")
#' }
ph_insight <- function(insight_id) {
  creds <- ph_check_auth()

  req <- httr2::request(creds$host) |>
    httr2::req_url_path_append("api", "projects", creds$project_id, "insights") |>
    httr2::req_url_query(short_id = insight_id) |>
    httr2::req_headers(Authorization = paste("Bearer", creds$api_key)) |>
    httr2::req_error(is_error = \(resp) FALSE)

  resp <- httr2::req_perform(req)
  status <- httr2::resp_status(resp)

  if (status >= 400) {
    cli::cli_abort("PostHog API request failed with status {status} while fetching insight {.val {insight_id}}.")
  }

  body <- httr2::resp_body_json(resp, simplifyVector = FALSE)

  if (length(body$results) == 0) {
    cli::cli_abort("No insight found with short ID {.val {insight_id}}.")
  }

  insight <- body$results[[1]]
  tibble::as_tibble(insight$result)
}
