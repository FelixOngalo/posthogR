library(testthat)
library(posthogR)

test_check("posthogR")
