test_that("ph_query rejects an empty sql string", {
  expect_error(ph_query(""), "non-empty")
})

test_that("ph_events builds WHERE clauses correctly", {
  # We can't hit the real API in tests, so this checks the SQL-building
  # logic indirectly by capturing what ph_post_query() receives.
  captured <- NULL
  testthat::local_mocked_bindings(
    ph_post_query = function(query_body) {
      captured <<- query_body
      list(columns = list(), results = list())
    },
    .package = "posthogR"
  )

  ph_events(event = "$pageview", since = "2026-09-01", limit = 50)

  expect_match(captured$query, "event = '\\$pageview'")
  expect_match(captured$query, "timestamp >= '2026-09-01'")
  expect_match(captured$query, "LIMIT 50")
})

test_that("ph_events with no filters omits WHERE entirely", {
  captured <- NULL
  testthat::local_mocked_bindings(
    ph_post_query = function(query_body) {
      captured <<- query_body
      list(columns = list(), results = list())
    },
    .package = "posthogR"
  )

  ph_events()

  expect_false(grepl("WHERE", captured$query))
})
