test_that("ph_auth stores credentials and ph_check_auth retrieves them", {
  ph_auth(api_key = "phx_test_key", project_id = "999", host = "https://example.posthog.com")

  creds <- ph_check_auth()
  expect_equal(creds$api_key, "phx_test_key")
  expect_equal(creds$project_id, "999")
  expect_equal(creds$host, "https://example.posthog.com")
})

test_that("ph_auth errors on missing api_key", {
  expect_error(ph_auth(api_key = "", project_id = "999"), "api_key")
})

test_that("ph_auth errors on missing project_id", {
  expect_error(ph_auth(api_key = "phx_test", project_id = ""), "project_id")
})

test_that("ph_check_auth errors with a helpful message when not authenticated", {
  # Simulate a fresh session by clearing the internal env
  rm(list = ls(envir = posthogR:::.posthogR_env), envir = posthogR:::.posthogR_env)
  expect_error(ph_check_auth(), "Not authenticated")
})
