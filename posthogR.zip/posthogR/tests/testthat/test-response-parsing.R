test_that("ph_response_to_tibble reshapes columns + results correctly", {
  resp <- list(
    columns = list("event", "count"),
    results = list(
      list("$pageview", 42),
      list("signup", 7)
    )
  )

  out <- posthogR:::ph_response_to_tibble(resp)

  expect_s3_class(out, "tbl_df")
  expect_equal(colnames(out), c("event", "count"))
  expect_equal(nrow(out), 2)
  expect_equal(out$event, c("$pageview", "signup"))
  expect_equal(out$count, c("42", "7"))  # character: see @return docs on type conversion
})

test_that("ph_response_to_tibble handles an empty result set", {
  resp <- list(columns = list("event", "count"), results = list())
  out <- posthogR:::ph_response_to_tibble(resp)

  expect_s3_class(out, "tbl_df")
  expect_equal(colnames(out), c("event", "count"))
  expect_equal(nrow(out), 0)
})
