# posthogR

An unofficial R client for the [PostHog](https://posthog.com) product
analytics API. PostHog ships official SDKs for several languages
(Python, JS, Rust, Elixir, and more) but not R. This package fills
that gap: authenticate with a personal API key, then pull PostHog data
— via raw HogQL, recent events, or a saved insight — straight into a
tibble.

**Status:** early scaffold / proof of concept, not yet on CRAN. Issues
and PRs welcome.

## Install

```r
# install.packages("devtools")
devtools::install_github("yourusername/posthogR")
```

## Quickstart

```r
library(posthogR)

# Store credentials for this session. Keep the key out of scripts you
# commit -- use an environment variable instead.
ph_auth(
  api_key    = Sys.getenv("POSTHOG_API_KEY"),
  project_id = "12345"
)

# Raw HogQL: PostHog's SQL-like query language
ph_query("SELECT event, count() FROM events GROUP BY event ORDER BY count() DESC LIMIT 10")

# Convenience wrapper for recent events
ph_events(event = "$pageview", since = "2026-09-01", limit = 500)

# Re-run a saved insight from the PostHog UI
ph_insight("AbCdEfGh")
```

## Why this exists

PostHog's REST API is well documented, but using it from R today means
hand-rolling `httr2` calls for every script. This package wraps that
once, so an R-based analyst can treat PostHog like any other data
source: write HogQL, get a tibble, pipe it into `ggplot2` or
`tidymodels` like anything else.

## Getting a personal API key

In PostHog: **Settings → Personal API Keys → + Create**. Scope it to
at least `query:read` (add `insight:read` if you'll use `ph_insight()`).
Store it as an environment variable rather than in code:

```
# .Renviron
POSTHOG_API_KEY=phx_your_key_here
```

## What's implemented

| Function | What it does |
|---|---|
| `ph_auth()` | Store API key, project ID, and host for the session |
| `ph_query()` | Run any HogQL query, get a tibble back |
| `ph_events()` | Convenience wrapper: recent events, optional event-name/date filters |
| `ph_insight()` | Re-run a saved insight by its short ID |

## Roadmap / good first issues

This is intentionally a minimal starting point. Natural next steps for
contributors:

- [ ] Type conversion: `ph_query()` currently returns all columns as
      character (HogQL's response doesn't carry R types). Add a
      `type_convert = TRUE` argument using the `types` field PostHog
      already returns.
- [ ] Pagination for `ph_events()` beyond a single request.
- [ ] `ph_feature_flag()` — evaluate a feature flag for a given
      distinct ID (mirrors what the other official SDKs provide).
- [ ] `ph_capture()` — send an event *to* PostHog (write side, not
      just read), for completeness with the other SDKs.
- [ ] Credential storage via `keyring` instead of session-only memory,
      for interactive use across sessions.
- [ ] CRAN submission once the API surface stabilizes.

## Design notes

- **Session, not disk, storage for the key.** `ph_auth()` stores
  credentials in an internal environment that lives only for the R
  session. This mirrors how most API-client packages in R behave
  (e.g. `googlesheets4`), and avoids ever accidentally writing a
  secret to disk.
- **Tibbles, not nested lists.** PostHog's raw HogQL response is
  `columns` + `results` (rows of untyped values). `ph_response_to_tibble()`
  reshapes that into one column per field — the format an R analyst
  actually wants to pipe into `dplyr`/`ggplot2`.
- **Every request goes through one internal function** (`ph_post_query()`),
  so auth, retries, and error handling live in exactly one place.

## Development

```r
devtools::load_all()
devtools::test()
devtools::document()
```

Tests use `testthat::local_mocked_bindings()` to check query-building
logic without hitting the live API.

## License

MIT
